var indexSectionsWithContent =
{
  0: "_abcdefghikmnprstuvwxäåæçèé",
  1: "_mn",
  2: "cegmp",
  3: "_efimpw",
  4: "abcdefghikmnprstuvw",
  5: "gsuxäåçèé",
  6: "æ"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "命名空间",
  3: "函数",
  4: "变量",
  5: "组",
  6: "页"
};

